﻿namespace OnlineBookstore
{
    internal class ApplicationDbContext
    {
    }
}