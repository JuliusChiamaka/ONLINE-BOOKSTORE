﻿using OnlineBookstore.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineBookstore.Service.Contract.Base
{
    public interface IPurchaseHistoryRepository
    {
        Task<IEnumerable<PurchaseHistory>> GetPurchaseHistoryByUserIdAsync(int userId);
        Task AddPurchaseHistoryAsync(PurchaseHistory history);
    }
}
